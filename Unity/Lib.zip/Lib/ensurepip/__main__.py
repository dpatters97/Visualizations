import ensurepip

if __name__ == "__main__":
    ensurepip._main()
